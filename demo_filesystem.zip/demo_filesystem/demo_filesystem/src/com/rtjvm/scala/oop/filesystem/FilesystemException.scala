package com.rtjvm.scala.oop.filesystem

class FilesystemException(message: String) extends RuntimeException(message) {

}
